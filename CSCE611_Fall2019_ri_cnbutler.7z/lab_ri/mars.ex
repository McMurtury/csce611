java -jar /usr/local/3rdparty/csce611/MARS/Mars.jar 
